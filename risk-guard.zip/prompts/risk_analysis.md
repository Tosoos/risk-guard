Analyze the crypto portfolio.

Return:
1. Risk score (0-100)
2. Concentration analysis
3. Stablecoin exposure
4. Diversification assessment
5. Rebalancing recommendations

Format output as JSON.
