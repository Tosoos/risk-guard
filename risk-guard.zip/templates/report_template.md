# Portfolio Risk Report

## Risk Score
{{risk_score}}

## Allocation
{{allocation}}

## Risks
{{risks}}

## Recommendations
{{recommendations}}

## Rebalancing Plan
{{rebalancing_plan}}
